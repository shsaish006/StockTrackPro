import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import io

# Set page configuration
st.set_page_config(
    page_title="Advanced Stock Analysis Dashboard",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for dark/light theme toggle and improved styling
st.markdown("""
<style>
    .stApp {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    .metric-card {
        background: rgba(255, 255, 255, 0.1);
        padding: 1rem;
        border-radius: 10px;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        margin: 0.5rem 0;
    }
    .sidebar .sidebar-content {
        background: rgba(0, 0, 0, 0.1);
    }
    .stSelectbox > div > div {
        background-color: rgba(255, 255, 255, 0.1);
        border-radius: 5px;
    }
    .stTextInput > div > div > input {
        background-color: rgba(255, 255, 255, 0.1);
        border-radius: 5px;
        color: white;
    }
    .quantitative-metrics {
        background: linear-gradient(45deg, #1e3c72, #2a5298);
        padding: 20px;
        border-radius: 15px;
        margin: 10px 0;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state for theme
if 'dark_mode' not in st.session_state:
    st.session_state.dark_mode = True

# Title and theme toggle
col1, col2 = st.columns([4, 1])
with col1:
    st.title("🚀 Advanced Stock Analysis Dashboard")
    st.markdown("**Real-time financial analysis with quantitative insights**")

with col2:
    if st.button("🌓 Toggle Theme"):
        st.session_state.dark_mode = not st.session_state.dark_mode
        st.rerun()

# Major company symbols for quick access
MAJOR_STOCKS = {
    "🍎 Apple": "AAPL",
    "🔍 Google": "GOOGL", 
    "🪟 Microsoft": "MSFT",
    "📦 Amazon": "AMZN",
    "⚡ Tesla": "TSLA",
    "💎 Meta": "META",
    "🎬 Netflix": "NFLX",
    "💳 Visa": "V",
    "🏦 JPMorgan": "JPM",
    "⚕️ Johnson & J": "JNJ",
    "🏠 Berkshire": "BRK-B",
    "🎯 Nvidia": "NVDA",
    "☁️ Salesforce": "CRM",
    "🎵 Spotify": "SPOT",
    "🚗 Ford": "F",
    "✈️ Boeing": "BA",
    "☕ Starbucks": "SBUX",
    "🛒 Walmart": "WMT",
    "🏪 Target": "TGT",
    "💊 Pfizer": "PFE"
}

# Sidebar for controls
with st.sidebar:
    st.header("🎯 Stock Selection")
    
    # Quick select major companies
    st.subheader("🏢 Major Companies")
    selected_company = st.selectbox(
        "Quick Select:",
        ["Select a company..."] + list(MAJOR_STOCKS.keys()),
        help="Choose from major publicly traded companies"
    )
    
    # Manual symbol input
    if selected_company != "Select a company...":
        symbol = MAJOR_STOCKS[selected_company]
        st.success(f"Selected: {symbol}")
    else:
        symbol = st.text_input(
            "Or enter custom symbol:",
            value="AAPL",
            help="Enter any valid stock ticker symbol"
        ).upper()
    
    st.divider()
    
    # Time period selection with more options
    st.subheader("📅 Analysis Period")
    period = st.selectbox(
        "Time Period:",
        ["1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "10y", "max"],
        index=5,
        help="Select historical data period"
    )
    
    # Interval selection
    interval_map = {
        "1 minute": "1m", "2 minutes": "2m", "5 minutes": "5m",
        "15 minutes": "15m", "30 minutes": "30m", "1 hour": "1h",
        "1 day": "1d", "5 days": "5d", "1 week": "1wk",
        "1 month": "1mo", "3 months": "3mo"
    }
    
    interval_label = st.selectbox(
        "Data Interval:",
        list(interval_map.keys()),
        index=6,
        help="Choose data granularity"
    )
    interval = interval_map[interval_label]
    
    st.divider()
    
    # Analysis options
    st.subheader("🔬 Analysis Options")
    show_volume = st.checkbox("Show Volume", value=True)
    show_ma = st.checkbox("Moving Averages", value=True)
    show_bollinger = st.checkbox("Bollinger Bands", value=True)
    show_rsi = st.checkbox("RSI Indicator", value=True)
    show_macd = st.checkbox("MACD", value=True)
    
    st.divider()
    
    # Quantitative analysis settings
    st.subheader("🧮 Quantitative Settings")
    risk_free_rate = st.slider("Risk-free Rate (%)", 0.0, 10.0, 2.0, 0.1)
    ma_short = st.slider("Short MA Period", 5, 50, 20)
    ma_long = st.slider("Long MA Period", 20, 200, 50)
    
    st.info("💡 **Tip**: Use different time periods and intervals to analyze various trading strategies!")

# Enhanced data fetching function
@st.cache_data(ttl=300)
def fetch_comprehensive_data(symbol, period, interval):
    """Fetch comprehensive stock data including all financial metrics"""
    try:
        stock = yf.Ticker(symbol)
        
        # Get historical data
        hist_data = stock.history(period=period, interval=interval)
        
        if hist_data.empty:
            return None, None, None, None, None, "No data available for this symbol"
        
        # Get stock info
        try:
            info = stock.info
        except:
            info = {}
        
        # Get financial statements
        try:
            financials = stock.financials
            balance_sheet = stock.balance_sheet
            cashflow = stock.cashflow
        except:
            financials = pd.DataFrame()
            balance_sheet = pd.DataFrame()
            cashflow = pd.DataFrame()
        
        return hist_data, info, financials, balance_sheet, cashflow, None
    except Exception as e:
        return None, None, None, None, None, str(e)

# Advanced technical indicators
def calculate_advanced_indicators(data, short_ma=20, long_ma=50):
    """Calculate comprehensive technical indicators"""
    if data is None or data.empty:
        return data
    
    # Ensure we have the required columns
    required_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
    available_cols = [col for col in required_cols if col in data.columns]
    
    if len(available_cols) < 4:  # Need at least OHLC
        return data
    
    # Moving Averages
    data[f'SMA_{short_ma}'] = data['Close'].rolling(window=short_ma).mean()
    data[f'SMA_{long_ma}'] = data['Close'].rolling(window=long_ma).mean()
    data['EMA_12'] = data['Close'].ewm(span=12).mean()
    data['EMA_26'] = data['Close'].ewm(span=26).mean()
    
    # MACD
    data['MACD'] = data['EMA_12'] - data['EMA_26']
    data['MACD_Signal'] = data['MACD'].ewm(span=9).mean()
    data['MACD_Histogram'] = data['MACD'] - data['MACD_Signal']
    
    # RSI
    delta = data['Close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    data['RSI'] = 100 - (100 / (1 + rs))
    
    # Bollinger Bands
    data['BB_Middle'] = data['Close'].rolling(window=20).mean()
    bb_std = data['Close'].rolling(window=20).std()
    data['BB_Upper'] = data['BB_Middle'] + (bb_std * 2)
    data['BB_Lower'] = data['BB_Middle'] - (bb_std * 2)
    data['BB_Width'] = data['BB_Upper'] - data['BB_Lower']
    data['BB_Position'] = (data['Close'] - data['BB_Lower']) / data['BB_Width']
    
    # Stochastic Oscillator
    lowest_low = data['Low'].rolling(window=14).min()
    highest_high = data['High'].rolling(window=14).max()
    data['Stoch_K'] = 100 * ((data['Close'] - lowest_low) / (highest_high - lowest_low))
    data['Stoch_D'] = data['Stoch_K'].rolling(window=3).mean()
    
    # Average True Range (ATR)
    high_low = data['High'] - data['Low']
    high_close = np.abs(data['High'] - data['Close'].shift())
    low_close = np.abs(data['Low'] - data['Close'].shift())
    ranges = pd.concat([high_low, high_close, low_close], axis=1)
    true_range = ranges.max(axis=1)
    data['ATR'] = true_range.rolling(window=14).mean()
    
    # Volume indicators
    if 'Volume' in data.columns:
        data['Volume_SMA'] = data['Volume'].rolling(window=20).mean()
        data['Volume_Ratio'] = data['Volume'] / data['Volume_SMA']
    
    return data

# Quantitative analysis functions
def calculate_quantitative_metrics(data, risk_free_rate=0.02):
    """Calculate advanced quantitative metrics"""
    if data is None or data.empty:
        return {}
    
    returns = data['Close'].pct_change().dropna()
    
    metrics = {}
    
    # Basic statistics
    metrics['Annual Return'] = returns.mean() * 252
    metrics['Annual Volatility'] = returns.std() * np.sqrt(252)
    metrics['Sharpe Ratio'] = (metrics['Annual Return'] - risk_free_rate) / metrics['Annual Volatility']
    
    # Downside metrics
    downside_returns = returns[returns < 0]
    if len(downside_returns) > 0:
        metrics['Downside Deviation'] = downside_returns.std() * np.sqrt(252)
        metrics['Sortino Ratio'] = (metrics['Annual Return'] - risk_free_rate) / metrics['Downside Deviation']
    else:
        metrics['Downside Deviation'] = 0
        metrics['Sortino Ratio'] = np.inf
    
    # Maximum Drawdown
    cumulative_returns = (1 + returns).cumprod()
    rolling_max = cumulative_returns.expanding().max()
    drawdown = (cumulative_returns - rolling_max) / rolling_max
    metrics['Max Drawdown'] = drawdown.min()
    
    # VaR and CVaR
    metrics['VaR (95%)'] = returns.quantile(0.05)
    metrics['CVaR (95%)'] = returns[returns <= metrics['VaR (95%)']].mean()
    
    # Skewness and Kurtosis
    metrics['Skewness'] = returns.skew()
    metrics['Kurtosis'] = returns.kurtosis()
    
    # Calmar Ratio
    metrics['Calmar Ratio'] = metrics['Annual Return'] / abs(metrics['Max Drawdown']) if metrics['Max Drawdown'] != 0 else np.inf
    
    return metrics

# Main application logic
if symbol:
    with st.spinner(f"🔄 Fetching comprehensive data for {symbol}..."):
        hist_data, info, financials, balance_sheet, cashflow, error = fetch_comprehensive_data(symbol, period, interval)
    
    if error:
        st.error(f"❌ Error: {error}")
        st.info("💡 Please check the symbol and try again. Use the quick select for major companies.")
    elif hist_data is None or hist_data.empty:
        st.error(f"❌ No data found for {symbol}")
        st.info("💡 Try a different symbol or time period.")
    else:
        # Calculate indicators
        hist_data = calculate_advanced_indicators(hist_data, ma_short, ma_long)
        
        # Company header with metrics
        if info:
            st.markdown("### 🏢 Company Overview")
            col1, col2, col3, col4, col5 = st.columns(5)
            
            with col1:
                company_name = info.get('longName', symbol)
                st.markdown(f"**{company_name}**")
                st.caption(f"Sector: {info.get('sector', 'N/A')}")
            
            with col2:
                current_price = info.get('currentPrice', info.get('regularMarketPrice', 0))
                previous_close = info.get('previousClose', 0)
                if current_price and previous_close:
                    change = current_price - previous_close
                    change_percent = (change / previous_close) * 100
                    st.metric("Price", f"${current_price:.2f}", f"{change:+.2f} ({change_percent:+.2f}%)")
                else:
                    latest_close = hist_data['Close'].iloc[-1] if not hist_data.empty else 0
                    prev_close = hist_data['Close'].iloc[-2] if len(hist_data) > 1 else latest_close
                    change = latest_close - prev_close
                    change_percent = (change / prev_close) * 100 if prev_close != 0 else 0
                    st.metric("Latest Price", f"${latest_close:.2f}", f"{change:+.2f} ({change_percent:+.2f}%)")
            
            with col3:
                market_cap = info.get('marketCap', 0)
                if market_cap:
                    if market_cap >= 1e12:
                        cap_str = f"${market_cap/1e12:.2f}T"
                    elif market_cap >= 1e9:
                        cap_str = f"${market_cap/1e9:.2f}B"
                    else:
                        cap_str = f"${market_cap/1e6:.2f}M"
                    st.metric("Market Cap", cap_str)
                else:
                    st.metric("Market Cap", "N/A")
            
            with col4:
                pe_ratio = info.get('trailingPE', 0)
                st.metric("P/E Ratio", f"{pe_ratio:.2f}" if pe_ratio else "N/A")
            
            with col5:
                volume = info.get('volume', hist_data['Volume'].iloc[-1] if 'Volume' in hist_data.columns else 0)
                if volume >= 1e9:
                    vol_str = f"{volume/1e9:.2f}B"
                elif volume >= 1e6:
                    vol_str = f"{volume/1e6:.2f}M"
                else:
                    vol_str = f"{volume/1e3:.0f}K"
                st.metric("Volume", vol_str)
        
        # Create tabs
        tab1, tab2, tab3, tab4, tab5 = st.tabs(["📈 Interactive Charts", "🧮 Quantitative Analysis", "💹 Technical Indicators", "📊 Financial Metrics", "📋 Data & Export"])
        
        with tab1:
            st.subheader(f"📈 Interactive Price Analysis - {symbol}")
            
            # Create subplots
            rows = 2 if show_volume else 1
            fig = make_subplots(
                rows=rows, cols=1,
                shared_xaxes=True,
                vertical_spacing=0.1,
                subplot_titles=(f'{symbol} Price Chart', 'Volume' if show_volume else ''),
                row_heights=[0.7, 0.3] if show_volume else [1.0]
            )
            
            # Candlestick chart
            fig.add_trace(
                go.Candlestick(
                    x=hist_data.index,
                    open=hist_data['Open'],
                    high=hist_data['High'],
                    low=hist_data['Low'],
                    close=hist_data['Close'],
                    name='Price',
                    increasing_line_color='#00ff88',
                    decreasing_line_color='#ff4444'
                ),
                row=1, col=1
            )
            
            # Add moving averages
            if show_ma:
                if f'SMA_{ma_short}' in hist_data.columns:
                    fig.add_trace(
                        go.Scatter(
                            x=hist_data.index,
                            y=hist_data[f'SMA_{ma_short}'],
                            name=f'SMA {ma_short}',
                            line=dict(color='orange', width=2)
                        ),
                        row=1, col=1
                    )
                
                if f'SMA_{ma_long}' in hist_data.columns:
                    fig.add_trace(
                        go.Scatter(
                            x=hist_data.index,
                            y=hist_data[f'SMA_{ma_long}'],
                            name=f'SMA {ma_long}',
                            line=dict(color='blue', width=2)
                        ),
                        row=1, col=1
                    )
            
            # Add Bollinger Bands
            if show_bollinger and all(col in hist_data.columns for col in ['BB_Upper', 'BB_Lower', 'BB_Middle']):
                fig.add_trace(
                    go.Scatter(
                        x=hist_data.index,
                        y=hist_data['BB_Upper'],
                        name='BB Upper',
                        line=dict(color='red', width=1),
                        fill=None
                    ),
                    row=1, col=1
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=hist_data.index,
                        y=hist_data['BB_Lower'],
                        name='BB Lower',
                        line=dict(color='red', width=1),
                        fill='tonexty',
                        fillcolor='rgba(255,0,0,0.1)'
                    ),
                    row=1, col=1
                )
            
            # Volume chart
            if show_volume and 'Volume' in hist_data.columns:
                colors = ['#ff4444' if close < open else '#00ff88' 
                         for close, open in zip(hist_data['Close'], hist_data['Open'])]
                fig.add_trace(
                    go.Bar(
                        x=hist_data.index,
                        y=hist_data['Volume'],
                        name='Volume',
                        marker_color=colors,
                        opacity=0.7
                    ),
                    row=2, col=1
                )
            
            fig.update_layout(
                title=f'{symbol} - {period.upper()} Analysis',
                yaxis_title='Price ($)',
                xaxis_rangeslider_visible=False,
                height=700,
                showlegend=True,
                template='plotly_dark' if st.session_state.dark_mode else 'plotly_white'
            )
            
            if show_volume:
                fig.update_yaxes(title_text="Volume", row=2, col=1)
            
            st.plotly_chart(fig, use_container_width=True)
        
        with tab2:
            st.subheader("🧮 Advanced Quantitative Analysis")
            
            # Calculate quantitative metrics
            quant_metrics = calculate_quantitative_metrics(hist_data, risk_free_rate/100)
            
            if quant_metrics:
                # Display metrics in cards
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.markdown('<div class="quantitative-metrics">', unsafe_allow_html=True)
                    st.markdown("**📈 Return Metrics**")
                    st.metric("Annual Return", f"{quant_metrics['Annual Return']*100:.2f}%")
                    st.metric("Sharpe Ratio", f"{quant_metrics['Sharpe Ratio']:.3f}")
                    st.metric("Sortino Ratio", f"{quant_metrics['Sortino Ratio']:.3f}")
                    st.markdown('</div>', unsafe_allow_html=True)
                
                with col2:
                    st.markdown('<div class="quantitative-metrics">', unsafe_allow_html=True)
                    st.markdown("**⚠️ Risk Metrics**")
                    st.metric("Annual Volatility", f"{quant_metrics['Annual Volatility']*100:.2f}%")
                    st.metric("Max Drawdown", f"{quant_metrics['Max Drawdown']*100:.2f}%")
                    st.metric("VaR (95%)", f"{quant_metrics['VaR (95%)']*100:.2f}%")
                    st.markdown('</div>', unsafe_allow_html=True)
                
                with col3:
                    st.markdown('<div class="quantitative-metrics">', unsafe_allow_html=True)
                    st.markdown("**📊 Distribution**")
                    st.metric("Skewness", f"{quant_metrics['Skewness']:.3f}")
                    st.metric("Kurtosis", f"{quant_metrics['Kurtosis']:.3f}")
                    st.metric("Calmar Ratio", f"{quant_metrics['Calmar Ratio']:.3f}")
                    st.markdown('</div>', unsafe_allow_html=True)
                
                # Returns distribution
                st.subheader("📊 Returns Distribution")
                returns = hist_data['Close'].pct_change().dropna()
                
                fig_dist = go.Figure()
                fig_dist.add_trace(go.Histogram(
                    x=returns,
                    nbinsx=50,
                    name='Returns Distribution',
                    marker_color='lightblue',
                    opacity=0.7
                ))
                
                fig_dist.update_layout(
                    title='Daily Returns Distribution',
                    xaxis_title='Returns',
                    yaxis_title='Frequency',
                    template='plotly_dark' if st.session_state.dark_mode else 'plotly_white'
                )
                
                st.plotly_chart(fig_dist, use_container_width=True)
                
                # Cumulative returns
                st.subheader("📈 Cumulative Performance")
                cumulative_returns = (1 + returns).cumprod()
                
                fig_cum = go.Figure()
                fig_cum.add_trace(go.Scatter(
                    x=cumulative_returns.index,
                    y=cumulative_returns,
                    name='Cumulative Returns',
                    line=dict(color='green', width=3)
                ))
                
                fig_cum.update_layout(
                    title='Cumulative Returns Over Time',
                    xaxis_title='Date',
                    yaxis_title='Cumulative Return',
                    template='plotly_dark' if st.session_state.dark_mode else 'plotly_white'
                )
                
                st.plotly_chart(fig_cum, use_container_width=True)
        
        with tab3:
            st.subheader("💹 Technical Indicators Dashboard")
            
            # RSI
            if show_rsi and 'RSI' in hist_data.columns:
                col1, col2 = st.columns(2)
                
                with col1:
                    fig_rsi = go.Figure()
                    fig_rsi.add_trace(
                        go.Scatter(
                            x=hist_data.index,
                            y=hist_data['RSI'],
                            name='RSI',
                            line=dict(color='purple', width=2)
                        )
                    )
                    fig_rsi.add_hline(y=70, line_dash="dash", line_color="red", annotation_text="Overbought")
                    fig_rsi.add_hline(y=30, line_dash="dash", line_color="green", annotation_text="Oversold")
                    fig_rsi.add_hline(y=50, line_dash="dot", line_color="gray", annotation_text="Neutral")
                    
                    fig_rsi.update_layout(
                        title='RSI (Relative Strength Index)',
                        yaxis_title='RSI',
                        height=350,
                        template='plotly_dark' if st.session_state.dark_mode else 'plotly_white'
                    )
                    st.plotly_chart(fig_rsi, use_container_width=True)
                
                with col2:
                    # Current RSI status
                    current_rsi = hist_data['RSI'].iloc[-1]
                    if current_rsi > 70:
                        rsi_status = "🔴 Overbought"
                        rsi_color = "red"
                    elif current_rsi < 30:
                        rsi_status = "🟢 Oversold"
                        rsi_color = "green"
                    else:
                        rsi_status = "🟡 Neutral"
                        rsi_color = "orange"
                    
                    st.metric("Current RSI", f"{current_rsi:.2f}", rsi_status)
                    
                    # RSI histogram
                    fig_rsi_hist = go.Figure()
                    fig_rsi_hist.add_trace(go.Histogram(
                        x=hist_data['RSI'].dropna(),
                        nbinsx=30,
                        marker_color=rsi_color,
                        opacity=0.7
                    ))
                    fig_rsi_hist.update_layout(
                        title='RSI Distribution',
                        xaxis_title='RSI Value',
                        yaxis_title='Frequency',
                        height=350,
                        template='plotly_dark' if st.session_state.dark_mode else 'plotly_white'
                    )
                    st.plotly_chart(fig_rsi_hist, use_container_width=True)
            
            # MACD
            if show_macd and 'MACD' in hist_data.columns:
                fig_macd = make_subplots(
                    rows=2, cols=1,
                    shared_xaxes=True,
                    vertical_spacing=0.1,
                    subplot_titles=('MACD Line & Signal', 'MACD Histogram'),
                    row_heights=[0.6, 0.4]
                )
                
                # MACD Line and Signal
                fig_macd.add_trace(
                    go.Scatter(
                        x=hist_data.index,
                        y=hist_data['MACD'],
                        name='MACD',
                        line=dict(color='blue', width=2)
                    ),
                    row=1, col=1
                )
                
                fig_macd.add_trace(
                    go.Scatter(
                        x=hist_data.index,
                        y=hist_data['MACD_Signal'],
                        name='Signal',
                        line=dict(color='red', width=2)
                    ),
                    row=1, col=1
                )
                
                # MACD Histogram
                colors = ['green' if val >= 0 else 'red' for val in hist_data['MACD_Histogram']]
                fig_macd.add_trace(
                    go.Bar(
                        x=hist_data.index,
                        y=hist_data['MACD_Histogram'],
                        name='Histogram',
                        marker_color=colors,
                        opacity=0.7
                    ),
                    row=2, col=1
                )
                
                fig_macd.add_hline(y=0, line_dash="dash", line_color="gray", row=1, col=1)
                fig_macd.add_hline(y=0, line_dash="dash", line_color="gray", row=2, col=1)
                
                fig_macd.update_layout(
                    title='MACD Analysis',
                    height=500,
                    template='plotly_dark' if st.session_state.dark_mode else 'plotly_white'
                )
                
                st.plotly_chart(fig_macd, use_container_width=True)
            
            # Stochastic Oscillator
            if 'Stoch_K' in hist_data.columns:
                fig_stoch = go.Figure()
                
                fig_stoch.add_trace(
                    go.Scatter(
                        x=hist_data.index,
                        y=hist_data['Stoch_K'],
                        name='%K',
                        line=dict(color='blue', width=2)
                    )
                )
                
                fig_stoch.add_trace(
                    go.Scatter(
                        x=hist_data.index,
                        y=hist_data['Stoch_D'],
                        name='%D',
                        line=dict(color='red', width=2)
                    )
                )
                
                fig_stoch.add_hline(y=80, line_dash="dash", line_color="red", annotation_text="Overbought")
                fig_stoch.add_hline(y=20, line_dash="dash", line_color="green", annotation_text="Oversold")
                
                fig_stoch.update_layout(
                    title='Stochastic Oscillator',
                    yaxis_title='Stochastic',
                    height=350,
                    template='plotly_dark' if st.session_state.dark_mode else 'plotly_white'
                )
                
                st.plotly_chart(fig_stoch, use_container_width=True)
        
        with tab4:
            st.subheader("📊 Comprehensive Financial Metrics")
            
            if info:
                # Valuation metrics
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("**💰 Valuation Metrics**")
                    valuation_data = {
                        "Metric": [
                            "P/E Ratio (TTM)", "Forward P/E", "PEG Ratio", "Price-to-Book",
                            "Price-to-Sales", "EV/Revenue", "EV/EBITDA", "Dividend Yield"
                        ],
                        "Value": [
                            f"{info.get('trailingPE', 0):.2f}" if info.get('trailingPE') else "N/A",
                            f"{info.get('forwardPE', 0):.2f}" if info.get('forwardPE') else "N/A",
                            f"{info.get('pegRatio', 0):.2f}" if info.get('pegRatio') else "N/A",
                            f"{info.get('priceToBook', 0):.2f}" if info.get('priceToBook') else "N/A",
                            f"{info.get('priceToSalesTrailing12Months', 0):.2f}" if info.get('priceToSalesTrailing12Months') else "N/A",
                            f"{info.get('enterpriseToRevenue', 0):.2f}" if info.get('enterpriseToRevenue') else "N/A",
                            f"{info.get('enterpriseToEbitda', 0):.2f}" if info.get('enterpriseToEbitda') else "N/A",
                            f"{info.get('dividendYield', 0)*100:.2f}%" if info.get('dividendYield') else "N/A"
                        ]
                    }
                    st.dataframe(pd.DataFrame(valuation_data), hide_index=True, use_container_width=True)
                
                with col2:
                    st.markdown("**🎯 Profitability & Growth**")
                    profitability_data = {
                        "Metric": [
                            "Profit Margin", "Operating Margin", "ROA", "ROE",
                            "Revenue Growth", "Earnings Growth", "Beta", "52W Range"
                        ],
                        "Value": [
                            f"{info.get('profitMargins', 0)*100:.2f}%" if info.get('profitMargins') else "N/A",
                            f"{info.get('operatingMargins', 0)*100:.2f}%" if info.get('operatingMargins') else "N/A",
                            f"{info.get('returnOnAssets', 0)*100:.2f}%" if info.get('returnOnAssets') else "N/A",
                            f"{info.get('returnOnEquity', 0)*100:.2f}%" if info.get('returnOnEquity') else "N/A",
                            f"{info.get('revenueGrowth', 0)*100:.2f}%" if info.get('revenueGrowth') else "N/A",
                            f"{info.get('earningsGrowth', 0)*100:.2f}%" if info.get('earningsGrowth') else "N/A",
                            f"{info.get('beta', 0):.2f}" if info.get('beta') else "N/A",
                            f"${info.get('fiftyTwoWeekLow', 0):.2f} - ${info.get('fiftyTwoWeekHigh', 0):.2f}" if info.get('fiftyTwoWeekLow') and info.get('fiftyTwoWeekHigh') else "N/A"
                        ]
                    }
                    st.dataframe(pd.DataFrame(profitability_data), hide_index=True, use_container_width=True)
                
                # Financial health score
                st.subheader("🏥 Financial Health Score")
                
                # Calculate a simple health score
                health_factors = {
                    'Profitability': info.get('profitMargins', 0) * 100 if info.get('profitMargins') else 0,
                    'Growth': info.get('revenueGrowth', 0) * 100 if info.get('revenueGrowth') else 0,
                    'Efficiency': info.get('returnOnEquity', 0) * 100 if info.get('returnOnEquity') else 0,
                    'Valuation': 100 - min(info.get('trailingPE', 50), 50) * 2 if info.get('trailingPE') else 50
                }
                
                health_score = sum(max(0, min(score, 100)) for score in health_factors.values()) / len(health_factors)
                
                # Display health score
                col1, col2, col3, col4, col5 = st.columns(5)
                
                with col1:
                    st.metric("Overall Score", f"{health_score:.1f}/100")
                
                for i, (factor, score) in enumerate(health_factors.items()):
                    with [col2, col3, col4, col5][i]:
                        normalized_score = max(0, min(score, 100))
                        color = "🟢" if normalized_score > 70 else "🟡" if normalized_score > 40 else "🔴"
                        st.metric(factor, f"{normalized_score:.1f}", color)
        
        with tab5:
            st.subheader("📋 Data Table & Export Options")
            
            # Data display options
            col1, col2 = st.columns(2)
            
            with col1:
                show_indicators = st.checkbox("Include Technical Indicators", value=False)
                max_rows = st.slider("Rows to display", 10, 500, 100)
            
            with col2:
                data_format = st.selectbox("Data Format", ["Raw Values", "Formatted", "Percentage Change"])
            
            # Prepare display data
            display_data = hist_data.tail(max_rows).copy()
            
            if not show_indicators:
                # Keep only basic OHLCV data
                basic_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
                available_basic = [col for col in basic_columns if col in display_data.columns]
                display_data = display_data[available_basic]
            
            # Format data based on selection
            if data_format == "Formatted":
                price_columns = ['Open', 'High', 'Low', 'Close']
                for col in price_columns:
                    if col in display_data.columns:
                        display_data[col] = display_data[col].round(2)
                
                if 'Volume' in display_data.columns:
                    display_data['Volume'] = display_data['Volume'].astype(int)
            
            elif data_format == "Percentage Change":
                for col in display_data.select_dtypes(include=[np.number]).columns:
                    display_data[f'{col}_Change%'] = display_data[col].pct_change() * 100
            
            st.dataframe(display_data, use_container_width=True)
            
            # Export options
            st.subheader("💾 Export Data")
            
            export_col1, export_col2, export_col3 = st.columns(3)
            
            with export_col1:
                # Full dataset export
                csv_buffer = io.StringIO()
                hist_data.to_csv(csv_buffer)
                csv_data = csv_buffer.getvalue()
                
                st.download_button(
                    label="📊 Download Full Dataset (CSV)",
                    data=csv_data,
                    file_name=f"{symbol}_complete_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv",
                    help="Complete dataset with all indicators and metrics"
                )
            
            with export_col2:
                # Basic price data only
                basic_columns = [col for col in ['Open', 'High', 'Low', 'Close', 'Volume'] if col in hist_data.columns]
                basic_data = hist_data[basic_columns].copy()
                
                basic_csv_buffer = io.StringIO()
                basic_data.to_csv(basic_csv_buffer)
                basic_csv_data = basic_csv_buffer.getvalue()
                
                st.download_button(
                    label="📈 Download Price Data (CSV)",
                    data=basic_csv_data,
                    file_name=f"{symbol}_price_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv",
                    help="Basic OHLCV price data only"
                )
            
            with export_col3:
                # Quantitative metrics export
                if 'quant_metrics' in locals():
                    metrics_df = pd.DataFrame.from_dict(quant_metrics, orient='index', columns=['Value'])
                    metrics_csv_buffer = io.StringIO()
                    metrics_df.to_csv(metrics_csv_buffer)
                    metrics_csv_data = metrics_csv_buffer.getvalue()
                    
                    st.download_button(
                        label="🧮 Download Metrics (CSV)",
                        data=metrics_csv_data,
                        file_name=f"{symbol}_quantitative_metrics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                        mime="text/csv",
                        help="Quantitative analysis metrics"
                    )
            
            # Data summary
            st.subheader("📊 Dataset Summary")
            summary_col1, summary_col2, summary_col3, summary_col4 = st.columns(4)
            
            with summary_col1:
                st.metric("Total Records", len(hist_data))
            with summary_col2:
                date_range = (hist_data.index[-1] - hist_data.index[0]).days
                st.metric("Date Range (Days)", date_range)
            with summary_col3:
                if 'High' in hist_data.columns:
                    st.metric("Highest Price", f"${hist_data['High'].max():.2f}")
            with summary_col4:
                if 'Low' in hist_data.columns:
                    st.metric("Lowest Price", f"${hist_data['Low'].min():.2f}")

else:
    # Welcome screen
    st.markdown("""
    ## 🚀 Welcome to Advanced Stock Analysis Dashboard
    
    ### Features:
    - 📈 **Interactive Charts**: Real-time candlestick charts with technical indicators
    - 🧮 **Quantitative Analysis**: Advanced metrics like Sharpe ratio, VaR, drawdown analysis
    - 💹 **Technical Indicators**: RSI, MACD, Bollinger Bands, Stochastic Oscillator
    - 📊 **Financial Metrics**: Comprehensive valuation and profitability analysis
    - 💾 **Data Export**: Download analysis data in multiple formats
    - 🌓 **Theme Toggle**: Switch between dark and light modes
    - 🏢 **Quick Access**: Pre-loaded major company stocks
    
    ### Quick Start:
    1. Select a major company from the sidebar dropdown
    2. Or enter any stock symbol manually
    3. Customize your analysis period and indicators
    4. Explore the comprehensive analysis across all tabs
    
    ### Popular Symbols:
    """)
    
    # Display popular symbols in a nice grid
    symbol_cols = st.columns(4)
    popular_symbols = [
        ("🍎 AAPL", "Apple Inc."),
        ("🔍 GOOGL", "Alphabet Inc."),
        ("⚡ TSLA", "Tesla Inc."),
        ("💎 META", "Meta Platforms"),
        ("🪟 MSFT", "Microsoft Corp."),
        ("📦 AMZN", "Amazon.com Inc."),
        ("🎬 NFLX", "Netflix Inc."),
        ("🎯 NVDA", "NVIDIA Corp.")
    ]
    
    for i, (symbol, name) in enumerate(popular_symbols):
        with symbol_cols[i % 4]:
            st.info(f"**{symbol}**\n{name}")

# Footer
st.markdown("---")
st.markdown(
    """
    <div style='text-align: center; color: #888;'>
        <p>📊 Advanced Stock Analysis Dashboard | Powered by Yahoo Finance API | Real-time Financial Data</p>
        <p>⚠️ <em>This tool is for educational and informational purposes only. Not financial advice.</em></p>
    </div>
    """, 
    unsafe_allow_html=True
)